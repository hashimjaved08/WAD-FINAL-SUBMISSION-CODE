<div class="row">
    <div class="col-sm-12">
        <h1>customer</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ID</th>

            </tr>
            </thead>
            <tbody>
            <?php
            $get_cust = "select * from customer";
            $run_cust = mysqli_query($con,$get_cust);
            $count_cust = mysqli_num_rows($run_cust);
            if($count_cust==0){
                echo "<h2> No customer found in selected criteria </h2>";
            }
            else {
                $i = 0;
                while ($row_cust = mysqli_fetch_array($run_cust)) {
                    $cust_id = $row_cust['cust_id'];
                    $fname = $row_cust['fname'];
                    $lname = $row_cust['lname'];
                    ?>
                    <tr>
                        <th scope="row"><?php echo ++$i; ?></th>
                        <td><?php echo $fname; ?></td>
                        <td><a href="index.php?edit_cust=<?php echo $cust_id?>" class="btn btn-primary">
                                <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="index.php?del_cust=<?php echo $cust_id?>" class="btn btn-danger">
                                <i class="fa fa-trash-alt"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
            </tbody>
        </table>
    </div>
</div>