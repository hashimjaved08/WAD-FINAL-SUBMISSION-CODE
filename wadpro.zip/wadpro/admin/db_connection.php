<?php
$con = mysqli_connect("localhost","root","","joblelo_pk");
if(!$con)
    die("Connection failed");