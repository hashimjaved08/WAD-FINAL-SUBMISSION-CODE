<?php
if(!isset($_SESSION['admin_email'])){
    header('location: login.php?not_admin=You are not Admin!');
}

if (isset($_POST['insert_cust'])) {
    $cust_id = test_input($_POST['cust_id']);
    $fname = test_input($_POST['fname']);
    $lname = test_input($_POST['lname']);

    if (!preg_match("/[a-zA-Z]+/", $fname) || strlen($fname) < 2) {
        $response = array(
            "type" => "warning",
            "message" => "Enter Valid customer first name."
        );
    }
    if (!preg_match("/[a-zA-Z]+/", $lname) || strlen($lname) < 2) {
        $response = array(
            "type" => "warning",
            "message" => "Enter Valid customer last name."
        );
    }

}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>

<h1 class="text-center my-4"><i class="fas fa-plus fa-md"></i> <span class="d-none d-sm-inline"> Add New </span>
    customer </h1>
<?php if (!empty($response)) { ?>
    <div class="alert alert-<?php echo $response["type"]; ?>">
        <?php echo $response["message"]; ?>
    </div>
<?php } ?>
<form action="" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="cust_id" class="float-md-right"> <span class="d-sm-none d-md-inline"> customer </span>
                id:</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-file-signature"></i></div>
                </div>
                <input type="text" class="form-control" id="cust_id" name="cust_id"
                       placeholder="Enter customer ID"
                    <?php
                    if (@$response["type"] == "warning") {
                        echo "value='$cust_id'";
                    }
                    ?>
                >
            </div>
        </div>
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="fname" class="float-md-right"><span class="d-sm-none d-md-inline"> customer </span>
                First Name:</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4 mt-3 mt-lg-0">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-list-alt"></i></div>
                </div>
                <input class="form-control" type="text" id="fname" name="fname"
                       placeholder="Enter customer first name">
            </div>
        </div>
    </div>

        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto">
            <label for="lname" class="float-md-right"><span class="d-sm-none d-md-inline"> customer </span>
                Last name:</label>
        </div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4 mt-3 mt-lg-0">
            <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-key"></i></div>
                </div>
                <input class="form-control" type="text" id="lname" name="lname"
                       placeholder="Enter customer last name">
            </div>
        </div>
    </div>
    <div class="row my-3">
        <div class="d-none d-sm-block col-sm-3 col-md-4 col-lg-2 col-xl-2 mt-auto"></div>
        <div class="col-sm-9 col-md-8 col-lg-4 col-xl-4">
            <button type="submit" name="insert_cust" class="btn btn-primary btn-block"><i class="fas fa-plus"></i>
                Insert Now
            </button>
        </div>
    </div>
</form>