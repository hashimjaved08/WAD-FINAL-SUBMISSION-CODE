<?php
if(!isset($_SESSION['admin_email'])){
    header('location: login.php?not_admin=You are not Admin!');
}
if(isset($_GET['edit_cust'])) {
    $get_id = $_GET['edit_cust'];
    $get_cust = "select * from customer where cust_id='$get_id'";
    $run_cust = mysqli_query($con, $get_cust);
    $row_cust = mysqli_fetch_array($run_cust);
    $cust_id = $row_cust['cust_id'];
    $fname = $row_cust['fname'];
    $lname = $row_cust['lname'];
    $email = $row_cust['email'];
    $newpass = $row_cust['newpass'];
    $confirmpass = $row_cust['confirmpass'];
    $dob = $row_cust['dob'];
}


if(isset($_POST['update_cust'])){
    //getting text data from the fields
    $cust_id = $_POST['cust_id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];

    $update_customer = "update customer setcust_id = '$cust_id' ,
                                        cust_fname = '$fname'
                                        cust_lname = '$lname' 
                                        where cust_id='$cust_id'";

    $update_cust = mysqli_query($con, $update_customer);
    if($update_cust){
        header("location: index.php?view_customer");
    }
}
?>
<div class="row">
    <div class="offset-md-2 col-md-8">
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group row">
                <h2 class="offset-lg-3 offset-md-2 offset-1 "> Edit & Update customer </h2>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="fname">customer first name</label>
                <div class="col-12 col-sm-8 col-lg-9">
                    <input class="form-control" type="text" id="fname" name="fname" placeholder="First Name"
                           value="<?php echo $fname;?>">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="lname">customer last name</label>
                <div class="col-12 col-sm-8 col-lg-9">
                    <input class="form-control" type="text" id="lname" name="lname" placeholder="Last Name"
                           value="<?php echo $lname;?>">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="email">customer email</label>
                <div class="col-12 col-sm-8 col-lg-9">
                    <input class="form-control" type="email" id="email" name="email" placeholder="Email"
                           value="<?php echo $email;?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="offset-sm-3 col-12 col-sm-6">
                    <input class="btn btn-block btn-primary btn-lg" type="submit" id="update_cust" name="update_cust"
                           value="Update Customer Now">
                </div>
            </div>
        </form>
    </div>
</div>