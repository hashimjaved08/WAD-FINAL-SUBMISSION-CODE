<?php
if(!isset($_SESSION['admin_email'])){
    header('location: login.php?not_admin=You are not Admin!');
}
if(isset($_GET['del_job'])){
    $del_id = $_GET['del_job'];
    $del_job = "delete from job where job_id='$del_id'";
    $run_del = mysqli_query($con,$del_job);
    if($run_del){
        header('location: index.php?view_job');
    }
}