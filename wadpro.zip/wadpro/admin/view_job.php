<div class="row">
    <div class="col-sm-12">
        <h1>Job</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ID</th>

            </tr>
            </thead>
            <tbody>
            <?php
            $get_job = "select * from job";
            $run_job = mysqli_query($con,$get_job);
            $count_job = mysqli_num_rows($run_job);
            if($count_job==0){
                echo "<h2> No jobs found in selected criteria </h2>";
            }
            else {
                $i = 0;
                while ($row_job = mysqli_fetch_array($run_job)) {
                    $job_id = $row_job['job_id'];
                    $job_name = $row_job['job_name'];
                    ?>
                    <tr>
                        <th scope="row"><?php echo ++$i; ?></th>
                        <td><?php echo $job_name; ?></td>
                        <td><a href="index.php?edit_job=<?php echo $job_id?>" class="btn btn-primary">
                                <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="index.php?del_job=<?php echo $job_id?>" class="btn btn-danger">
                                <i class="fa fa-trash-alt"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
            </tbody>
        </table>
    </div>
</div>