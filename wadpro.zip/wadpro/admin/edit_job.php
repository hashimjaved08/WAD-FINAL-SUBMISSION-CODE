<?php
if(!isset($_SESSION['admin_email'])){
    header('location: login.php?not_admin=You are not Admin!');
}
if(isset($_GET['edit_job'])) {
    $get_id = $_GET['edit_job'];
    $get_job = "select * from job where job_id='$get_id'";
    $run_job = mysqli_query($con, $get_job);
    $row_job = mysqli_fetch_array($run_job);
    $job_id = $row_job['job_id'];
    $job_name = $row_job['job_name'];
}

if(isset($_POST['update_job'])){
    //getting text data from the fields
    $job_id = $_POST['job_id'];
    $job_name = $_POST['job_name'];

    $update_job = "update job set job_id = '$job_id' ,
                                        job_name = '$job_name'
                                        where job_id='$job_id'";

    $update_job = mysqli_query($con, $update_job);
    if($update_job){
        header("location: index.php?view_job");
    }
}
?>
<div class="row">
    <div class="offset-md-2 col-md-8">
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group row">
                <h2 class="offset-lg-3 offset-md-2 offset-1 "> Edit & Update Job </h2>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="job_name">Job name</label>
                <div class="col-12 col-sm-8 col-lg-9">
                    <input class="form-control" type="text" id="job_name" name="job_name" placeholder="Job Name"
                           value="<?php echo $job_name;?>">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="job_id">Job ID</label>
                <div class="col-12 col-sm-8 col-lg-9">
                    <input class="form-control" type="text" id="job_id" name="job_id" placeholder="Job ID"
                           value="<?php echo $job_id;?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="offset-sm-3 col-12 col-sm-6">
                    <input class="btn btn-block btn-primary btn-lg" type="submit" id="update_job" name="update_job"
                           value="Update Job Now">
                </div>
            </div>
        </form>
    </div>
</div>