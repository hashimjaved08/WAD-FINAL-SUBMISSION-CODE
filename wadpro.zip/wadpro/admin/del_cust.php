<?php
if(!isset($_SESSION['admin_email'])){
    header('location: login.php?not_admin=You are not Admin!');
}
if(isset($_GET['del_cust'])){
    $del_id = $_GET['del_cust'];
    $del_cust = "delete from customer where cust_id='$del_id'";
    $run_del = mysqli_query($con,$del_cust);
    if($run_del){
        header('location: index.php?view_cust');
    }
}