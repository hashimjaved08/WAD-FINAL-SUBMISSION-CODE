<?php
require_once "db_connection.php";
function getcust(){
    global $con;
    $getCustQuery = '';
    if(!isset($_GET['fname']) && !isset($_GET['lname']) && !isset($_GET['email'])){
        $getCustQuery = "select * from customer order by RAND();";
    }
    else if(isset($_GET['fname'])){
        $fname = $_GET['fname'];
        $getCustQuery = "select * from customer where fname = '$fname'";
    }
    else if(isset($_GET['lname'])){
        $lname = $_GET['lname'];
        $getCustQuery = "select * from customer where lname = '$lname'";
    }
    else if(isset($_GET['email'])){
        $email = $_GET['email'];
        $getCustQuery = "select * from customer where email = 'email'";
    }
    $getCustResult = mysqli_query($con,$getCustQuery);
    $count_cust = mysqli_num_rows($getCustResult);
    if($count_cust==0){
        echo "<h4 class='alert-warning align-center my-2 p-2'> No Customers found in selected criteria </h4>";
    }
    while($row = mysqli_fetch_assoc($getCustResult)){
        $cust_id = $row['cust_id'];
        $fname = $row['fname'];
        $lname = $row['lname'];
    }
}
